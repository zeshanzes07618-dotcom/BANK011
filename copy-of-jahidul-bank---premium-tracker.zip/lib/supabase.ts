
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://ackjcaqxwznkhydkracn.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFja2pjYXF4d3pua2h5ZGtyYWNuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAxOTMxODEsImV4cCI6MjA4NTc2OTE4MX0.4iU-9yLeEmEXXdD5K-EjGUVNqCwkH1trCZBWpEOJB1U';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
