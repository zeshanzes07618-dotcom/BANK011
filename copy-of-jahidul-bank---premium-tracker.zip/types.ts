
export type TransactionType = 'IN' | 'OUT';

export interface Transaction {
  id: string;
  name: string;
  amount: number;
  type: TransactionType;
  date: string;
}

export interface Account {
  id: string;
  name: string;
  balance: number;
}

export type AppView = 'VAULT' | 'AUTH' | 'DASHBOARD' | 'HISTORY' | 'ACCOUNTS';
