
import React from 'react';
import { LayoutDashboard, History, Landmark, Users, Settings } from 'lucide-react';
import { AppView } from '../types';

interface SidebarProps {
  activeView: AppView;
  setView: (view: AppView) => void;
  userName: string;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setView, userName }) => {
  const menuItems = [
    { id: 'DASHBOARD', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'HISTORY', icon: History, label: 'Transactions' },
    { id: 'ACCOUNTS', icon: Landmark, label: 'Accounts' },
  ];

  return (
    <aside className="fixed bottom-0 left-0 w-full lg:w-64 lg:h-full lg:relative glass border-t lg:border-t-0 lg:border-r border-white/10 z-40">
      <div className="hidden lg:flex flex-col h-full p-6">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 gold-gradient rounded-xl flex items-center justify-center">
            <Landmark className="text-black w-6 h-6" />
          </div>
          <span className="text-xl font-black tracking-tight">JB PREMIUM</span>
        </div>

        <div className="flex-1 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id as AppView)}
              className={`w-full flex items-center gap-4 px-4 py-4 rounded-xl transition-all duration-300 ${
                activeView === item.id 
                  ? 'bg-yellow-500/10 text-yellow-500' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="font-semibold">{item.label}</span>
              {activeView === item.id && (
                <div className="ml-auto w-1.5 h-1.5 bg-yellow-500 rounded-full" />
              )}
            </button>
          ))}
        </div>

        <div className="mt-auto p-4 bg-white/5 rounded-2xl">
          <div className="flex items-center gap-3">
            <img src={`https://picsum.photos/seed/${userName}/100/100`} className="w-10 h-10 rounded-full border-2 border-yellow-500" />
            <div className="overflow-hidden">
              <p className="font-bold truncate text-sm">{userName}</p>
              <p className="text-xs text-gray-500">Premium Member</p>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className="flex lg:hidden justify-around items-center p-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as AppView)}
            className={`p-2 rounded-lg ${activeView === item.id ? 'text-yellow-500' : 'text-gray-400'}`}
          >
            <item.icon className="w-6 h-6" />
          </button>
        ))}
      </div>
    </aside>
  );
};

export default Sidebar;
