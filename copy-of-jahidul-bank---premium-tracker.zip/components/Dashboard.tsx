
import React, { useState } from 'react';
/* Added AnimatePresence to resolve undefined name error */
import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, TrendingDown, Plus, CreditCard, DollarSign, Calendar } from 'lucide-react';
import { Transaction } from '../types';

interface DashboardProps {
  transactions: Transaction[];
  totals: { cashIn: number; cashOut: number; balance: number };
  onAddTransaction: (name: string, amount: number, type: 'IN' | 'OUT', date: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ transactions, totals, onAddTransaction }) => {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ name: '', amount: '', type: 'IN', date: '2026-02-01' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.amount) return;
    onAddTransaction(formData.name, parseFloat(formData.amount), formData.type as 'IN' | 'OUT', formData.date);
    setFormData({ name: '', amount: '', type: 'IN', date: '2026-02-01' });
    setShowModal(false);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="max-w-6xl mx-auto pb-24 lg:pb-0"
    >
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
        <div>
          <h2 className="text-4xl font-black text-white">Dashboard</h2>
          <p className="text-gray-400 flex items-center gap-2 mt-1">
            <Calendar className="w-4 h-4 text-yellow-500" />
            February 2026 Statement
          </p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="gold-gradient text-black px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-yellow-500/20 hover:scale-105 active:scale-95 transition-all"
        >
          <Plus className="w-6 h-6" />
          Add Transaction
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <motion.div variants={itemVariants} className="glass p-8 rounded-[2rem] relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 blue-gradient blur-[80px] opacity-20" />
          <p className="text-gray-400 text-sm font-semibold mb-2 flex items-center gap-2 uppercase tracking-widest">
            <CreditCard className="w-4 h-4 text-blue-500" /> Total Balance
          </p>
          <h3 className="text-4xl font-black text-white">৳ {totals.balance.toLocaleString()}</h3>
          <div className="mt-4 flex items-center gap-2 text-blue-400 text-sm bg-blue-500/10 w-fit px-3 py-1 rounded-full">
            <TrendingUp className="w-4 h-4" /> Account Active
          </div>
        </motion.div>

        <motion.div variants={itemVariants} className="glass p-8 rounded-[2rem] border-emerald-500/20">
          <p className="text-gray-400 text-sm font-semibold mb-2 uppercase tracking-widest flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-500" /> Cash In (Received)
          </p>
          <h3 className="text-4xl font-black text-emerald-400">৳ {totals.cashIn.toLocaleString()}</h3>
        </motion.div>

        <motion.div variants={itemVariants} className="glass p-8 rounded-[2rem] border-rose-500/20">
          <p className="text-gray-400 text-sm font-semibold mb-2 uppercase tracking-widest flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-rose-500" /> Cash Out (Spent)
          </p>
          <h3 className="text-4xl font-black text-rose-400">৳ {totals.cashOut.toLocaleString()}</h3>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div variants={itemVariants} className="glass p-8 rounded-[2rem]">
          <h4 className="text-xl font-bold mb-6 flex items-center justify-between">
            Recent Activity
            <button className="text-yellow-500 text-sm hover:underline">View All</button>
          </h4>
          <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
            {transactions.length === 0 ? (
              <div className="text-center py-12 opacity-50">
                <DollarSign className="w-12 h-12 mx-auto mb-2" />
                <p>No transactions recorded yet.</p>
              </div>
            ) : (
              transactions.slice(0, 5).map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl hover:bg-white/10 transition-colors cursor-pointer group">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${tx.type === 'IN' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                      {tx.type === 'IN' ? <TrendingUp className="w-6 h-6" /> : <TrendingDown className="w-6 h-6" />}
                    </div>
                    <div>
                      <p className="font-bold text-white group-hover:text-yellow-500 transition-colors">{tx.name}</p>
                      <p className="text-xs text-gray-500">{new Date(tx.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <p className={`font-bold text-lg ${tx.type === 'IN' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {tx.type === 'IN' ? '+' : '-'} ৳{tx.amount.toLocaleString()}
                  </p>
                </div>
              ))
            )}
          </div>
        </motion.div>

        <motion.div variants={itemVariants} className="glass p-8 rounded-[2rem] flex flex-col items-center justify-center text-center">
            <div className="w-32 h-32 rounded-full border-8 border-yellow-500/20 border-t-yellow-500 mb-6 flex items-center justify-center">
                <span className="text-2xl font-black text-yellow-500">100%</span>
            </div>
            <h4 className="text-2xl font-bold mb-2">Savings Progress</h4>
            <p className="text-gray-400 max-w-xs">You are maintaining a strong financial profile for February 2026.</p>
            <div className="w-full h-2 bg-white/5 rounded-full mt-8 overflow-hidden">
                <div className="h-full gold-gradient w-[100%]" />
            </div>
        </motion.div>
      </div>

      {/* Add Transaction Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass w-full max-w-md p-8 rounded-[2.5rem] relative z-10"
            >
              <h3 className="text-2xl font-bold mb-6">Record Transaction</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Entity Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-yellow-500/50 outline-none"
                    placeholder="e.g. Salary, Rent, Food"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Amount (৳)</label>
                  <input 
                    type="number" 
                    required
                    value={formData.amount}
                    onChange={e => setFormData({...formData, amount: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-yellow-500/50 outline-none"
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Transaction Type</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, type: 'IN'})}
                      className={`py-3 rounded-xl font-bold transition-all ${formData.type === 'IN' ? 'bg-emerald-500 text-black' : 'bg-slate-900 text-gray-400 border border-slate-700'}`}
                    >
                      Cash In
                    </button>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, type: 'OUT'})}
                      className={`py-3 rounded-xl font-bold transition-all ${formData.type === 'OUT' ? 'bg-rose-500 text-white' : 'bg-slate-900 text-gray-400 border border-slate-700'}`}
                    >
                      Cash Out
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Date</label>
                  <input 
                    type="date" 
                    required
                    value={formData.date}
                    onChange={e => setFormData({...formData, date: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-yellow-500/50 outline-none"
                  />
                </div>
                <div className="pt-4 flex gap-4">
                  <button 
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 py-4 border border-slate-700 rounded-xl font-bold hover:bg-white/5 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 gold-gradient text-black py-4 rounded-xl font-bold shadow-lg shadow-yellow-500/20"
                  >
                    Confirm
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default Dashboard;
