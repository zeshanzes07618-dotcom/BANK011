
import React from 'react';
import { motion } from 'framer-motion';

const VaultIntro: React.FC = () => {
  return (
    <div className="relative flex flex-col items-center">
      <motion.div
        className="w-64 h-64 border-8 border-gray-800 rounded-full relative flex items-center justify-center"
        initial={{ scale: 0.8, rotate: -45 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ duration: 1.5, ease: "easeOut" }}
      >
        {/* Outer Wheel Spikes */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-10 bg-gray-700"
            style={{
              transform: `rotate(${i * 45}deg) translateY(-140px)`
            }}
          />
        ))}
        
        {/* Inner Wheel */}
        <motion.div 
          className="w-48 h-48 border-4 border-yellow-600/50 rounded-full flex items-center justify-center vault-wheel"
        >
          <div className="w-40 h-1 bg-gray-700 absolute rotate-45" />
          <div className="w-40 h-1 bg-gray-700 absolute -rotate-45" />
          <div className="w-4 h-4 bg-yellow-500 rounded-full z-10" />
        </motion.div>

        {/* Closing Ring */}
        <motion.div 
          className="absolute inset-0 border-4 border-yellow-500 rounded-full"
          initial={{ opacity: 0, scale: 1.2 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
        />
      </motion.div>

      <motion.div
        className="mt-8 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
      >
        <h1 className="text-4xl font-black tracking-widest text-white mb-2">JAHIDUL BANK</h1>
        <p className="text-yellow-500/80 font-medium tracking-[0.3em] uppercase">Security • Premium • Trust</p>
      </motion.div>
    </div>
  );
};

export default VaultIntro;
