
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, ArrowUpDown, ChevronDown, Download, Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import { Transaction } from '../types';

interface HistoryViewProps {
  transactions: Transaction[];
  totals: { cashIn: number; cashOut: number; balance: number };
}

const HistoryView: React.FC<HistoryViewProps> = ({ transactions, totals }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'IN' | 'OUT'>('ALL');

  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = tx.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'ALL' || tx.type === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="max-w-6xl mx-auto h-full flex flex-col"
    >
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
        <div>
          <h2 className="text-4xl font-black text-white">Statement History</h2>
          <p className="text-gray-400 mt-1">Detailed audit of all BDT movements</p>
        </div>
        <div className="flex gap-4">
          <button className="glass px-6 py-3 rounded-xl flex items-center gap-2 hover:bg-white/10 transition-all text-sm font-semibold">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </header>

      {/* Summary Mini Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-2xl flex items-center justify-between">
           <div>
              <p className="text-emerald-500 text-xs font-bold uppercase tracking-wider">Weekly Income</p>
              <p className="text-xl font-black text-emerald-400">৳{totals.cashIn.toLocaleString()}</p>
           </div>
           <TrendingUp className="text-emerald-500 w-8 h-8 opacity-50" />
        </div>
        <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-2xl flex items-center justify-between">
           <div>
              <p className="text-rose-500 text-xs font-bold uppercase tracking-wider">Weekly Expenses</p>
              <p className="text-xl font-black text-rose-400">৳{totals.cashOut.toLocaleString()}</p>
           </div>
           <TrendingDown className="text-rose-500 w-8 h-8 opacity-50" />
        </div>
        <div className="bg-yellow-500/10 border border-yellow-500/20 p-4 rounded-2xl flex items-center justify-between">
           <div>
              <p className="text-yellow-500 text-xs font-bold uppercase tracking-wider">Current Liquidity</p>
              <p className="text-xl font-black text-yellow-500">৳{totals.balance.toLocaleString()}</p>
           </div>
           <div className="w-8 h-8 gold-gradient rounded-full opacity-50" />
        </div>
      </div>

      <div className="glass rounded-[2rem] flex-1 flex flex-col overflow-hidden min-h-0">
        <div className="p-6 border-b border-white/5 flex flex-wrap gap-4 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-3 w-5 h-5 text-gray-500" />
            <input 
              type="text" 
              placeholder="Search by name or reference..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pl-12 focus:outline-none focus:ring-2 focus:ring-yellow-500/50"
            />
          </div>
          <div className="flex gap-3">
            <select 
              value={filterType}
              onChange={e => setFilterType(e.target.value as any)}
              className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-500/50"
            >
              <option value="ALL">All Types</option>
              <option value="IN">Cash In</option>
              <option value="OUT">Cash Out</option>
            </select>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 scroll-smooth">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-[#05070a]/80 backdrop-blur-md z-10">
              <tr className="text-gray-500 text-xs uppercase tracking-[0.15em] border-b border-white/5">
                <th className="px-6 py-4 font-black">Date</th>
                <th className="px-6 py-4 font-black">Entity/Description</th>
                <th className="px-6 py-4 font-black text-right">Amount</th>
                <th className="px-6 py-4 font-black text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredTransactions.map((tx) => (
                <motion.tr 
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  key={tx.id} 
                  className="hover:bg-white/5 transition-colors group cursor-pointer"
                >
                  <td className="px-6 py-5 text-sm font-medium text-gray-400">
                    {new Date(tx.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${tx.type === 'IN' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      <span className="font-bold text-white group-hover:text-yellow-500 transition-colors">{tx.name}</span>
                    </div>
                  </td>
                  <td className={`px-6 py-5 text-right font-black text-lg ${tx.type === 'IN' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {tx.type === 'IN' ? '+' : '-'} ৳{tx.amount.toLocaleString()}
                  </td>
                  <td className="px-6 py-5 text-center">
                    <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-emerald-500/20 text-emerald-500">
                      Settled
                    </span>
                  </td>
                </motion.tr>
              ))}
              {filteredTransactions.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-20 text-center text-gray-500">
                    No matching transactions found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
};

export default HistoryView;
