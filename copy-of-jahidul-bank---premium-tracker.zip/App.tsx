
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Power, Landmark } from 'lucide-react';
import VaultIntro from './components/VaultIntro';
import Auth from './components/Auth';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import HistoryView from './components/HistoryView';
import { Transaction, AppView, Account } from './types';
import { supabase } from './lib/supabase';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('VAULT');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([
    { id: '1', name: 'Main Savings', balance: 0 }
  ]);

  // Check auth session
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchTransactions(session.user.id);
        setView('DASHBOARD');
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchTransactions(session.user.id);
        setView('DASHBOARD');
      } else {
        setView('AUTH');
        setTransactions([]);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchTransactions = async (userId: string) => {
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false });
    
    if (data) setTransactions(data);
  };

  useEffect(() => {
    if (view === 'VAULT') {
      const timer = setTimeout(() => {
        if (!user) setView('AUTH');
        else setView('DASHBOARD');
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [view, user]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  const addTransaction = async (name: string, amount: number, type: 'IN' | 'OUT', date: string) => {
    if (!user) return;

    const newTx = {
      name,
      amount,
      type,
      date,
      user_id: user.id
    };

    const { data, error } = await supabase
      .from('transactions')
      .insert([newTx])
      .select();

    if (data) {
      setTransactions([data[0] as Transaction, ...transactions]);
    }
  };

  const totals = useMemo(() => {
    const cashIn = transactions.filter(t => t.type === 'IN').reduce((sum, t) => sum + t.amount, 0);
    const cashOut = transactions.filter(t => t.type === 'OUT').reduce((sum, t) => sum + t.amount, 0);
    return {
      cashIn,
      cashOut,
      balance: cashIn - cashOut
    };
  }, [transactions]);

  if (loading && view !== 'VAULT') return null;

  return (
    <div className="min-h-screen bg-[#05070a] text-white selection:bg-yellow-500/30">
      <AnimatePresence mode="wait">
        {view === 'VAULT' && (
          <motion.div
            key="vault"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            transition={{ duration: 0.8 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070a]"
          >
            <VaultIntro />
          </motion.div>
        )}

        {view === 'AUTH' && !user && (
          <motion.div
            key="auth"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex items-center justify-center min-h-screen p-4"
          >
            <Auth />
          </motion.div>
        )}

        {user && (
          <div className="flex min-h-screen">
            <button 
              onClick={handleLogout}
              className="fixed top-6 right-6 z-50 p-3 rounded-full glass hover:bg-red-500/20 text-red-500 transition-all duration-300 group"
              title="Power Off"
            >
              <Power className="w-6 h-6 group-hover:scale-110" />
            </button>

            <Sidebar 
              activeView={view} 
              setView={setView} 
              userName={user.user_metadata?.full_name || "Jahidul Islam"} 
            />

            <main className="flex-1 lg:ml-64 p-4 lg:p-8 pt-20 lg:pt-8 overflow-y-auto h-screen">
              <AnimatePresence mode="wait">
                {view === 'DASHBOARD' && (
                  <Dashboard 
                    key="dashboard"
                    transactions={transactions} 
                    totals={totals}
                    onAddTransaction={addTransaction}
                  />
                )}
                {view === 'HISTORY' && (
                  <HistoryView 
                    key="history"
                    transactions={transactions} 
                    totals={totals}
                  />
                )}
                {view === 'ACCOUNTS' && (
                  <div className="p-8 glass rounded-3xl text-center">
                    <Landmark className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
                    <h2 className="text-2xl font-bold mb-4">Multiple Accounts Management</h2>
                    <p className="text-gray-400 mb-8">Connect and track your various BDT bank accounts in one premium portal.</p>
                    <button className="gold-gradient px-8 py-3 rounded-xl text-black font-bold hover:opacity-90 transition-all">
                      Add New Account
                    </button>
                  </div>
                )}
              </AnimatePresence>
            </main>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
